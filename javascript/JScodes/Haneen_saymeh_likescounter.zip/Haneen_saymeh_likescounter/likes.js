
var x = document.querySelector("#label1");
var count = 3;

function countlikes(){
    count ++;
    
    x.innerText = count + "likes";
}

