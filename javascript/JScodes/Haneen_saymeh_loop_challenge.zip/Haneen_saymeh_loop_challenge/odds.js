for (var x = 1; x <21; x++){
    if (x  % 2 != 0){
        console.log(x)
    }
}