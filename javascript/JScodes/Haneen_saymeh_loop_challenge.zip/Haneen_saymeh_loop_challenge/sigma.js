var sum = 0;
for (var x =1; x <101; x++){
    sum = sum+x;
}

console.log(sum)