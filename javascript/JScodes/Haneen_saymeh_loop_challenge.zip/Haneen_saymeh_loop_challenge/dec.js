for (var x=100; x>=0; x--){
    if (x % 3 ==0){
        console.log(x);
    }
}