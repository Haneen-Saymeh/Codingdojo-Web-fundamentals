var product = 1;
for (var x =1; x <13; x++){
    product = product*x;
}

console.log(product)