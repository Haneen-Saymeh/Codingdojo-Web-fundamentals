
function play(ele){

    ele.play();
    
    
}

function pause(ele){
    ele.pause();
}