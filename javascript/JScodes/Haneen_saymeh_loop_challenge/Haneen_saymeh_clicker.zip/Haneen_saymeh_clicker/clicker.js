

function change(element){
    element.innerText="Logout";
}


function remove(element2){
    element2.remove()
}